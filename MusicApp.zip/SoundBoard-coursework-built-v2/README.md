
docker compose down -v   (to wipe from php and read from sql
docker compose up --build
